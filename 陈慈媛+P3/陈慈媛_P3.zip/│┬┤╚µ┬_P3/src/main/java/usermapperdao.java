package dao;

import java.util.List;

import pojo.User;

/**
 * 这个类用来完成用户表的业务
 *
 * @author Administrator
 *
 */
public interface UserMapperDao {
    // <select id="findAll" resultType="User">
    // select * from user
    // </select>
    // 查询所有表的所有数据
    public List<User> findAll();

    // <select id="count" resultType="int">
    // select count(*) from user
    // </select>
    public int count();

    // <select id="findOne" parameterType="int" resultType="User">
    // select * from user where id=#{id}
    // </select>
    public User findOne(int id);

    // <insert id="save" parameterType="User">
    // insert into user values(null,#{name},#{addr},#{age})
    // </insert>
    public void save(User user);

    // <update id="updateUser" parameterType="User" >
    // update user <set> age=#{age}</set> <where>name=#{name}</where>
    // </update>
    public void updateUser(User user);

    // <delete id="deleteUser" parameterType="User">
    // delete from user where name=#{name}
    // </delete>
    public void deleteUser(User user);
}